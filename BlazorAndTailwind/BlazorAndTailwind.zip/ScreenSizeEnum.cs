﻿using Microsoft.JSInterop;

namespace BlazorAndTailwind;

public enum ScreenSize
{
    Xs = 0,    // Extra small devices
    Sm = 640,  // Small devices
    Md = 768,  // Medium devices
    Lg = 1024, // Large devices
    Xl = 1280  // Extra large devices
}


