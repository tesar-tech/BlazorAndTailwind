module.exports = {
    content: [
        './**/*.html',
        './**/*.razor',
    ],
    theme: {
        extend: {

        },
    },
    plugins: [],
}
